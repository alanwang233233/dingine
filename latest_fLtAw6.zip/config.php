<?php
$frameurl = "https://api.lxyddice.top/wang/latest";
$framekey = "ujdksghfuyegfuysd114514";