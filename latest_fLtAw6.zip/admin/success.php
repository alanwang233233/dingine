<!DOCTYPE html>
<html>
<head>
    <title>Login Success</title>
</head>
<body>
    <h1>成功，正在重定向</h1>
    <meta http-equiv="refresh" content="0; URL=admin.php">
    <p>如果你的浏览器没有自动重定向，那么点击： <a href="admin.php">click here</a>.</p>
    </body>
</html>