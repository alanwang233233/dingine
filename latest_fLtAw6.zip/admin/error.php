<!DOCTYPE html>
<html>
<head>
    <title>Login Error</title>
</head>
<body>
    <h1>登录失败</h1>
    <meta http-equiv="refresh" content="0; URL=admin.php">
    <p>如果你的浏览器没有自动重定向，那么点击： <a href="login.php">click here</a>.</p>
</body>
</html>

