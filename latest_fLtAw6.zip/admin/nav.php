    <!-- Navbar -->
  <nav class="navbar navbar-expand-md navbar-light bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">钉钉机器人后台管理系统 <span class="badge bg-secondary"> 内测</span></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" href="plugin.php">插件管理</a>
          </li>
            <li class="nav-item">
            <a class="nav-link active" href="test.php">在线测试</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">退出登录</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>