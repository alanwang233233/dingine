<?php
$users = array(
  'admin' => array(
    'password' => 'wang123456',
    'apikey' => 'apikey',
    'dingtalkuserid' => '114514',
    'cubebbsid' => '114514',
    'isadmin' => '1'
  ),
  'lxyddice' => array(
    'password' => '11223344',
    'apikey' => 'apikey1',
    'dingtalkuserid' => '1145141',
    'cubebbsid' => '1919810',
    'isadmin' => '1'
  ),
);