帮助：
numbergame [数字]   猜数字小游戏
daily 每日早报
ai [问题] 公益的ChatGPT，可能会卡，卡了就等一会
yiyan 一言
guessnum 猜数字小游戏，可以用guessnum help获得帮助

Powered By 钉擎🤖1.2.0 Beta