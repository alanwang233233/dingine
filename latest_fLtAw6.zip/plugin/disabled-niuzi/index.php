<?php
$cs = $_GET["cs"];
